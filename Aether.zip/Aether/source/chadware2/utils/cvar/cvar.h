#pragma once
// Minimal Source 2 ConVar finder/setter for client commands like viewmodel_* and world visuals.

namespace CvarUtil
{
    // Returns true if the named float cvar was written.
    bool SetFloat(const char* name, float value);
    // Returns true if the named float cvar was read into *out.
    bool GetFloat(const char* name, float* out);
    // Best-effort int write (fog_enable, fog_override, etc.).
    bool SetInt(const char* name, int value);
    // Best-effort string write (sv_skyname). May no-op if layout unknown.
    bool SetString(const char* name, const char* value);
}
