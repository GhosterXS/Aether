// AETHER_CVAR_FIX_20261016
#include "cvar.h"

#include <Windows.h>
#include <cstdio>
#include <cstring>

namespace
{
    using CreateInterfaceFn = void* (*)(const char* name, int* returnCode);

    void* GetInterface(const char* moduleName, const char* prefix)
    {
        HMODULE mod = GetModuleHandleA(moduleName);
        if (!mod)
            return nullptr;
        auto create = reinterpret_cast<CreateInterfaceFn>(GetProcAddress(mod, "CreateInterface"));
        if (!create)
            return nullptr;
        char buf[64];
        for (int v = 0; v <= 20; ++v)
        {
            if (v == 0)
                std::snprintf(buf, sizeof(buf), "%s", prefix);
            else
                std::snprintf(buf, sizeof(buf), "%s%03d", prefix, v);
            int rc = 0;
            void* p = create(buf, &rc);
            if (p)
                return p;
        }
        return nullptr;
    }

    void* FindConVarRaw(void* icvar, const char* name)
    {
        if (!icvar || !name || !*name)
            return nullptr;
        using Fn = void* (__fastcall*)(void*, const char*);
        void** vt = *reinterpret_cast<void***>(icvar);
        if (!vt)
            return nullptr;

        const int candidates[] = {
            10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
            7, 8, 9, 21, 22, 25, 30, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45
        };
        for (int idx : candidates)
        {
            __try
            {
                auto fn = reinterpret_cast<Fn>(vt[idx]);
                if (!fn)
                    continue;
                void* cv = fn(icvar, name);
                if (cv)
                    return cv;
            }
            __except (EXCEPTION_EXECUTE_HANDLER) {}
        }
        return nullptr;
    }

    unsigned char* AsBytes(void* p)
    {
        return reinterpret_cast<unsigned char*>(p);
    }

    bool WriteFloatValue(void* cvar, float value)
    {
        if (!cvar)
            return false;
        const int offs[] = {
            0x40, 0x48, 0x50, 0x58, 0x60, 0x68, 0x70, 0x78,
            0x38, 0x3C, 0x44, 0x4C, 0x54, 0x5C, 0x64, 0x6C,
            0x80, 0x84, 0x88, 0x8C, 0x90, 0x28, 0x2C, 0x30, 0x34
        };
        bool any = false;
        for (int o : offs)
        {
            __try
            {
                float* p = reinterpret_cast<float*>(AsBytes(cvar) + o);
                float prev = *p;
                if (prev != prev)
                    continue;
                if (prev < -1.0e6f || prev > 1.0e6f)
                    continue;
                *p = value;
                any = true;
            }
            __except (EXCEPTION_EXECUTE_HANDLER) {}
        }
        return any;
    }

    bool WriteIntValue(void* cvar, int value)
    {
        if (!cvar)
            return false;
        const int offs[] = {
            0x40, 0x48, 0x50, 0x58, 0x60, 0x68, 0x38, 0x3C, 0x44, 0x4C, 0x30, 0x34, 0x28, 0x2C
        };
        bool any = false;
        for (int o : offs)
        {
            __try
            {
                int* p = reinterpret_cast<int*>(AsBytes(cvar) + o);
                int prev = *p;
                if (prev > 100000000 || prev < -100000000)
                    continue;
                *p = value;
                any = true;
            }
            __except (EXCEPTION_EXECUTE_HANDLER) {}
        }
        return WriteFloatValue(cvar, static_cast<float>(value)) || any;
    }

    bool ReadFloatValue(void* cvar, float* out)
    {
        if (!cvar || !out)
            return false;
        const int offs[] = {
            0x40, 0x48, 0x50, 0x58, 0x60, 0x68, 0x70, 0x78,
            0x38, 0x3C, 0x44, 0x4C, 0x54, 0x28, 0x2C, 0x30, 0x34
        };
        for (int o : offs)
        {
            __try
            {
                float v = *reinterpret_cast<float*>(AsBytes(cvar) + o);
                if (v != v)
                    continue;
                if (v < -1.0e6f || v > 1.0e6f)
                    continue;
                *out = v;
                return true;
            }
            __except (EXCEPTION_EXECUTE_HANDLER) {}
        }
        return false;
    }

    void* g_icvar = nullptr;

    void* ICvar()
    {
        if (g_icvar)
            return g_icvar;
        const char* modules[] = { "tier0.dll", "engine2.dll", "client.dll", "vstdlib.dll" };
        const char* names[] = { "VEngineCvar007", "VEngineCvar", "Cvar", "VCvar", "VEngineCvar00" };
        for (auto* m : modules)
        {
            for (auto* n : names)
            {
                void* p = GetInterface(m, n);
                if (p)
                {
                    g_icvar = p;
                    return p;
                }
            }
        }
        return nullptr;
    }
}

bool CvarUtil::SetFloat(const char* name, float value)
{
    void* icvar = ICvar();
    if (!icvar)
        return false;
    void* cv = FindConVarRaw(icvar, name);
    if (!cv)
        return false;
    return WriteFloatValue(cv, value);
}

bool CvarUtil::GetFloat(const char* name, float* out)
{
    void* icvar = ICvar();
    if (!icvar)
        return false;
    void* cv = FindConVarRaw(icvar, name);
    if (!cv)
        return false;
    return ReadFloatValue(cv, out);
}

bool CvarUtil::SetInt(const char* name, int value)
{
    void* icvar = ICvar();
    if (!icvar)
        return false;
    void* cv = FindConVarRaw(icvar, name);
    if (!cv)
        return false;
    return WriteIntValue(cv, value);
}

bool CvarUtil::SetString(const char* name, const char* value)
{
    (void)name;
    (void)value;
    return false;
}
